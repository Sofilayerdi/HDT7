package com.example;

public class ProductTraversal implements ITraversal<String, Producto> {
    private boolean ascending;
    
    public ProductTraversal(boolean ascending) {
        this.ascending = ascending;
    }
    
    @Override
    public void visitar(BinaryTreeNode<String, Producto> actualNode) {
        Producto producto = actualNode.get_value();
        System.out.println("SKU: " + producto.getSku() + 
                         ", Nombre: " + producto.getProductName() + 
                         ", Categoría: " + producto.getCategory() + 
                         ", Precio Retail: " + producto.getPriceRetail() + 
                         ", Precio Actual: " + producto.getPriceCurrent());
    }
}