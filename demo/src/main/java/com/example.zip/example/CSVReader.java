package com.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader {
    public static BinarySearchTree<String, Producto> loadProductsFromCSV(String filePath) {
        BinarySearchTree<String, Producto> bst = new BinarySearchTree<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean firstLine = true; // Para saltar el encabezado
            
            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                
                String[] values = line.split(",");
                if (values.length >= 5) {
                    String sku = values[0].trim();
                    double priceRetail = Double.parseDouble(values[1].trim());
                    double priceCurrent = Double.parseDouble(values[2].trim());
                    String productName = values[3].trim();
                    String category = values[4].trim();
                    
                    Producto producto = new Producto(sku, priceRetail, priceCurrent, productName, category);
                    bst.insert(sku, producto);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return bst;
    }
}