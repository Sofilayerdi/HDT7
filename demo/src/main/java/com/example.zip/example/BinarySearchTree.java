package com.example;

public class BinarySearchTree<K extends Comparable<K>, V> implements IBinaryTree<K, V> {
    private BinaryTreeNode<K, V> root;
    private int count;

    public BinarySearchTree() {
        root = null;
        count = 0;
    }

    @Override
    public int count() {
        return count;
    }

    @Override
    public boolean isEmpty() {
        return root == null;
    }

    @Override
    public void insert(K key, V value) {
        if (isEmpty()) {
            root = new BinaryTreeNode<>(key, value, null, false);
            count++;
        } else {
            insertNode(root, key, value);
        }
    }

    private void insertNode(BinaryTreeNode<K, V> node, K key, V value) {
        int comparison = key.compareTo(node.get_key());
        
        if (comparison < 0) {
            if (node.get_leftChild() == null) {
                node.set_leftChild(new BinaryTreeNode<>(key, value, node, false));
                count++;
            } else {
                insertNode(node.get_leftChild(), key, value);
            }
        } else if (comparison > 0) {
            if (node.get_rightChild() == null) {
                node.set_rightChild(new BinaryTreeNode<>(key, value, node, true));
                count++;
            } else {
                insertNode(node.get_rightChild(), key, value);
            }
        } else {
            node.set_value(value);
        }
    }

    @Override
    public V search(K keyToFind) {
        return searchNode(root, keyToFind);
    }

    private V searchNode(BinaryTreeNode<K, V> node, K keyToFind) {
        if (node == null) {
            return null;
        }

        int comparison = keyToFind.compareTo(node.get_key());
        
        if (comparison == 0) {
            return node.get_value();
        } else if (comparison < 0) {
            return searchNode(node.get_leftChild(), keyToFind);
        } else {
            return searchNode(node.get_rightChild(), keyToFind);
        }
    }

    @Override
    public V remove(K key) {
        BinaryTreeNode<K, V> nodeToRemove = findNode(root, key);
        if (nodeToRemove == null) {
            return null;
        }
        
        V value = nodeToRemove.get_value();
        
        
        count--;
        return value;
    }

    private BinaryTreeNode<K, V> findNode(BinaryTreeNode<K, V> node, K key) {
        if (node == null) {
            return null;
        }

        int comparison = key.compareTo(node.get_key());
        
        if (comparison == 0) {
            return node;
        } else if (comparison < 0) {
            return findNode(node.get_leftChild(), key);
        } else {
            return findNode(node.get_rightChild(), key);
        }
    }

    @Override
    public void InOrder(ITraversal<K, V> traversalMethod) {
        inOrderTraversal(root, traversalMethod);
    }

    private void inOrderTraversal(BinaryTreeNode<K, V> node, ITraversal<K, V> traversalMethod) {
        if (node != null) {
            inOrderTraversal(node.get_leftChild(), traversalMethod);
            traversalMethod.visitar(node);
            inOrderTraversal(node.get_rightChild(), traversalMethod);
        }
    }

    @Override
    public void PreOrder(ITraversal<K, V> traversalMethod) {
        preOrderTraversal(root, traversalMethod);
    }

    private void preOrderTraversal(BinaryTreeNode<K, V> node, ITraversal<K, V> traversalMethod) {
        if (node != null) {
            traversalMethod.visitar(node);
            preOrderTraversal(node.get_leftChild(), traversalMethod);
            preOrderTraversal(node.get_rightChild(), traversalMethod);
        }
    }

    @Override
    public void PostOrder(ITraversal<K, V> traversalMethod) {
        postOrderTraversal(root, traversalMethod);
    }

    private void postOrderTraversal(BinaryTreeNode<K, V> node, ITraversal<K, V> traversalMethod) {
        if (node != null) {
            postOrderTraversal(node.get_leftChild(), traversalMethod);
            postOrderTraversal(node.get_rightChild(), traversalMethod);
            traversalMethod.visitar(node);
        }
    }
}