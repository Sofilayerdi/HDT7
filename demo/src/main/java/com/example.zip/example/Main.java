package com.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Cargar datos desde CSV
        BinarySearchTree<String, Producto> productTree = CSVReader.loadProductsFromCSV("datos.csv");
        
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\nMenú:");
            System.out.println("1. Buscar producto por SKU");
            System.out.println("2. Listar productos SKU ordenados ascendente");
            System.out.println("3. Listar productos SKU ordenados descendente");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            
            int option = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (option) {
                case 1:
                    System.out.print("Ingrese el SKU a buscar: ");
                    String sku = scanner.nextLine();
                    Producto producto = productTree.search(sku);
                    
                    if (producto != null) {
                        System.out.println("\nProducto encontrado:");
                        System.out.println("SKU: " + producto.getSku());
                        System.out.println("Nombre: " + producto.getProductName());
                        System.out.println("Categoría: " + producto.getCategory());
                        System.out.println("Precio Retail: " + producto.getPriceRetail());
                        System.out.println("Precio Actual: " + producto.getPriceCurrent());
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;
                    
                case 2:
                    System.out.println("\nProductos ordenados ascendente (por SKU):");
                    productTree.InOrder(new ProductTraversal(true));
                    break;
                    
                case 3:
                    System.out.println("\nProductos ordenados descendente (por SKU):");
                    // Para descendente, podrías implementar un reverse in-order traversal
                    // o modificar el ProductTraversal para invertir el orden
                    // Esta es una implementación simplificada
                    productTree.InOrder(new ProductTraversal(false));
                    break;
                    
                case 4:
                    System.out.println("Saliendo del programa...");
                    scanner.close();
                    System.exit(0);
                    break;
                    
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }
}