package com.example;

public class Producto {
    private String sku;
    private double priceRetail;
    private double priceCurrent;
    private String productName;
    private String category;

    public Producto(String sku, double priceRetail, double priceCurrent, String productName, String category) {
        this.sku = sku;
        this.priceRetail = priceRetail;
        this.priceCurrent = priceCurrent;
        this.productName = productName;
        this.category = category;
    }

    public String getSku() {
        return sku;
    }

    public double getPriceRetail() {
        return priceRetail;
    }

    public double getPriceCurrent() {
        return priceCurrent;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "Producto {" +
                "sku: '" + sku + '\'' +
                ", priceRetail: " + priceRetail +
                ", priceCurrent: " + priceCurrent +
                ", productName: '" + productName + '\'' +
                ", category: '" + category + '\'' +
                '}';
    }
}